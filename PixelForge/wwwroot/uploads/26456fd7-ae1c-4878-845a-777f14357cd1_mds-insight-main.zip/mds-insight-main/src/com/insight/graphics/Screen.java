package com.insight.graphics;

public class Screen extends Bitmap {
	public Screen(int width, int height, int[] pixels) {
		super(width, height, pixels);
	}
	
	public void render() {
		
	}
}
