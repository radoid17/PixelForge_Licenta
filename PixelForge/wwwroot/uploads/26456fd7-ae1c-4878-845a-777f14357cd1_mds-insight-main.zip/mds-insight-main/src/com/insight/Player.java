package com.insight;

public class Player {
	public String username;
	public int avatar, id;
	
	public Player(final String username, final int avatar) {
		this.username = username;
		this.avatar = avatar;
	}
}
